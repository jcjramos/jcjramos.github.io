---
title: "Ramos on Software"
---
Occasional words wisdom from someone working in the Software industry since the last millennium.
