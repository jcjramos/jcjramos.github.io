---
title: "About"
description: "Ramos on Software – Occasional words wisdom from someone working in the Software industry since the last millennium"
---

My name is José Ramos, I live in Lisbon – Portugal.  A long time ago, during the 80’s in the last millennium I’ve got a Sinclair ZX Spectrum as a gift …Instead of playing PacMac I’ve became fascinated how you could write a few commands and that tiny machine would do some many interesting stuff ( I was an odd kid …). Soon I’ve bought a book about Basic in a used bookstore and start leaning it, eventually discovered that I love doing that and wanted to do that as a career.

Although I don’t like Basic much these days I still love programming, I tend to use Java or C++ now. Currently I work as a Software Architect for a company in the Telecom Sector. Today I'm mostly focused in designing microservices, altougth I don’t program as much as I used to I’m still very closely involved with the Software development process.

After so many years working on Software I’ve decided in 2018 to create my on blog. As I really don’t like the way the Web is going these days, with more and more content behind walled gardens, I though about creating a old fashioned blog available for everyone who wishes to read it. 

## Some topics I'm likelly to cover :
* Kubernetes & Docker microservices
* Privacy & Software Security 
* Software Architecture 
* Software development & Java

## Some additional comments :

Keep in mind that English is not my first language, I’m a native Portuguese speaker, please don’t be offended if my use of English looks “odd”.

## Some credits for this site : 

* This blog name is a obvious inspiration from the well know ( and very interesting to read for many years ) blog Schneier on Security https://www.schneier.com/.
* Icons made by Gregor Cresnar  from Flat Icon is licensed by Creative Commons BY 3.0

## New home on GitHub
Originally this blog was hosted in wordpress, in the end of 2018 I've decided to move it to github and use a static generator ( https://www.gohugo.io ) to manage it. Reasonin is that this way I can handle the blog with much of the same tools that I use in everyday Software development. A plus is that the Markdown format is quite good to handle code examples, and I plan to focus on tuturials and technical aspects.