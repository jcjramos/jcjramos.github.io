---
title: Contact
type: page
menu:
  main: {}

---

I’m not a huge fan of social media, to contact me please use a old fashion email, address jcarlosr[dot here]pt[at here]gmail[and other dot]com. If you really like social media, eventually you can find me on LinkedIn.