---
layout: post
title: Read last week
date: 2018-03-05 11:37
author: jcarlosr
comments: true
categories: [current trends, news]
---
<a href="https://www.economist.com/news/leaders/21737501-policymakers-must-apply-lessons-horseless-carriage-driverless-car-self-driving"><strong>The economist on “self driving cars” </strong></a>

Particularly interesting is this part regarding privacy “<em>AVs will record everything that happens in and around them. When a crime is committed, the police will ask nearby cars if they saw anything. Fleet operators will know a great deal about their riders</em>”.

<a href="http://www.wired.co.uk/article/chinese-government-social-credit-score-privacy-invasion"><strong>Wired on China “Big Brother” Social Credits approach</strong></a>

Kind of old news, but found it last week …<em>"Imagine a world where many of your daily activities were constantly monitored and evaluated… It's not hard to picture, because most of that already happens…. But now imagine a system where all these behaviours are rated as either positive or negative and distilled into a single number, according to rules set by the government."</em>

<a href="https://techcrunch.com/2018/03/02/the-worlds-largest-ddos-attack-took-github-offline-for-less-than-tens-minutes/">Techcrunch on how GitHub survived the largest known DDos attack</a>
<p class="alpha tweet-title">The world’s largest DDoS attack took GitHub offline for fewer than 10 minutes</p>
