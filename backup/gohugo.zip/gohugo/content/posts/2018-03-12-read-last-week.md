---
layout: post
title: Read last week - MoviePass
date: 2018-03-12 13:53
author: jcarlosr
comments: true
categories: [current trends, news]
---
<strong>Wow</strong>

MoviePass CEO Mitch Lowe told an audience at a Hollywood event last Friday that the app <a href="https://techcrunch.com/2018/03/05/moviepass-ceo-proudly-says-the-app-tracks-your-location-before-and-after-movies/">tracks moviegoers' locations before and after each show they watch</a>. "We get an enormous amount of information,"

<a href="https://www.bleepingcomputer.com/news/security/hardcoded-password-found-in-cisco-software/"><strong>Hardcoded Password Found in Cisco Software</strong></a>

&nbsp;
