---
layout: post
title: Read last week - Cambridge Analytica
date: 2018-03-20 10:43
author: jcarlosr
comments: true
categories: [current trends, news]
---
<a href="http://www.bbc.com/news/technology-43465968">BBC on Cambridge Analytica</a>

Tech giant Facebook and data analytics firm Cambridge Analytica are at the centre of a dispute over the harvesting and use of personal dat

&nbsp;

<a href="http://bgr.com/2018/03/12/slingshot-malware-routers-infected-pcs/">BGR on Slingshot</a>

A nation-state developed a piece of malware so powerful that it can steal everything that’s happening on a computer without even being install on the target device itself. Instead, it resides on a router. It’s called Slingshot and it was recently discovered by Kaspersky Labs. Incredibly, the malware is so powerful and sophisticated that it hid in routers for six years before finally being spotted

&nbsp;

<a href="https://www.schneier.com/blog/archives/2018/03/the_600_compani.html">Schneier on GDPR </a>

One of the effects of GDPR -- the new EU General Data Protection Regulation -- is that we're all going to be learning a lot more about who collects our data and what they do with it. Consider PayPal, that <a href="https://www.paypal.com/ie/webapps/mpp/ua/third-parties-list">just released</a> a list of over 600 companies they share customer data with.
