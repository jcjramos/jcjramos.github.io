---
layout: post
title: Read Last Week - Everybody loves Facebook !
date: 2018-03-26 10:47
author: jcarlosr
comments: true
categories: [current trends, facebook, news]
---
<h5><a href="https://www.theregister.co.uk/2018/03/23/facebook_and_the_future/">The register </a></h5>
Facebook's inflection point: Now everyone knows this greedy mass surveillance operation for what it is
<h5></h5>
<h5><a href="https://yro.slashdot.org/story/18/03/25/056246/facebook-scraped-call-text-message-data-for-years-from-android-phones">Slashdot</a></h5>
This past week, a New Zealand man was looking through the data Facebook had collected from him in <a href="https://www.facebook.com/help/131112897028467?helpref=page_content">an archive</a> he had pulled down from the social networking site. While scanning the information Facebook had stored about his contacts, Dylan McKay discovered something distressing: <a href="https://arstechnica.com/information-technology/2018/03/facebook-scraped-call-text-message-data-for-years-from-android-phones/">Facebook also had about two years worth of phone call metadata from his Android phone</a>

&nbsp;
<h5><a href="https://qz.com/1236322/apples-steve-jobs-tried-to-warn-facebooks-mark-zuckerberg-about-privacy-years-before-the-cambridge-analytica-debacle/">QuartzMedia</a></h5>
Steve Jobs tried to warn Mark Zuckerberg about privacy in 2010

&nbsp;
