---
layout: post
title: Read last week - Whois GDPR ?
date: 2018-04-30 08:40
author: jcarlosr
comments: true
categories: [current trends, GDPR]
---
<h6>Hey, so Europe's GDPR privacy deadline for Whois? We're going to miss it ... by a year or so</h6>
<a href="https://www.theregister.co.uk/2018/04/10/gdpr_whois_regulations/">https://www.theregister.co.uk/2018/04/10/gdpr_whois_regulations/</a>
<h6>China “Social Credit Score”</h6>
<a href="http://newyork.cbslocal.com/2018/04/24/china-assigns-every-citizen-a-social-credit-score-to-identify-who-is-and-isnt-trustworthy/">http://newyork.cbslocal.com/2018/04/24/china-assigns-every-citizen-a-social-credit-score-to-identify-who-is-and-isnt-trustworthy/</a>
<h6>Google new Chat service</h6>
<a href="https://www.bleepingcomputer.com/news/google/google-accused-of-showing-total-contempt-for-android-users-privacy/">https://www.bleepingcomputer.com/news/google/google-accused-of-showing-total-contempt-for-android-users-privacy/</a>
