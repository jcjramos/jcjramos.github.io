---
layout: post
title: Read last week
date: 2018-10-12 16:46
author: jcarlosr
comments: true
categories: [current trends, security]
---
<h2>NotPetya</h2>
The <a href="https://www.wired.com/story/notpetya-cyberattack-ukraine-russia-code-crashed-the-world">Untold Story of NotPetya</a>, the Most Devastating Cyberattack in History.
<h2>Fear</h2>
At the Open Source Summit, Window Snyder, Chief Security Officer at Intel, explains <a href="http://www.eweek.com/security/what-developers-can-do-to-improve-cyber-security">why fear is not a good motivator for improving cyber-security</a> and provides insight into how to improve software defenses.
<h2><strong>Security </strong></h2>
In today's world, computers are now so omnipresent that there is no longer any such thing as cybersecurity, online security, or computer security – <a href="https://blog.codinghorror.com/there-is-no-longer-any-such-thing-as-computer-security/">there's only <em>security</em></a>. You either have it, or you don'
